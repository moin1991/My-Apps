export const getRewardPoints = (transaction) => {
	let points = 0;
	if (transaction > 100) {
		points = (transaction - 100) * 2 + 50;
	} else if (transaction > 50) {
		points = transaction - 50;
	}

	return promisify(points);
};

/**
 * Mimics an API call
 */
const promisify = (value) =>
	new Promise((resolve) => {
		setTimeout(() => {
			resolve(value);
		}, 1000);
	});
