import React from "react";
import { getRewardPoints } from "../actions/rewards";

const RewardCalculator = () => {
	const [reward, setReward] = React.useState(0);
	const [loading, setLoading] = React.useState(false);

	const onAmountEnter = (event) => {
		setLoading(true);
		const amount = event.target.value;
		getRewardPoints(amount).then((points) => {
			setReward(points);
			setLoading(false);
		});
	};

	return (
		<div>
			<label>Transaction Amount </label>
			<input type="number" onChange={onAmountEnter} />
			<br />
			<span>Reward points: </span>
			{loading ? "loading..." : reward}
		</div>
	);
};

export default RewardCalculator;
