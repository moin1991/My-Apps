import "./App.css";
import RewardCalculator from "./reward-calculator";

function App() {
	return (
		<div className="App">
			<RewardCalculator />
		</div>
	);
}

export default App;
